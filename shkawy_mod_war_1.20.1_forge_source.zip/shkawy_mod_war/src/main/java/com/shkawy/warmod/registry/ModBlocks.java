package com.shkawy.warmod.registry;

import com.shkawy.warmod.ShkawyModWar;
import com.shkawy.warmod.block.BarbedWireBlock;
import com.shkawy.warmod.block.LandmineBlock;
import com.shkawy.warmod.block.SpikePitBlock;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, ShkawyModWar.MODID);

    public static final RegistryObject<Block> SANDBAG = reg("sandbag", () ->
            new Block(BlockBehaviour.Properties.of().mapColor(MapColor.SAND).strength(1.5F, 6.0F).sound(SoundType.SAND)));

    public static final RegistryObject<Block> BUNKER_CONCRETE = reg("bunker_concrete", () ->
            new Block(BlockBehaviour.Properties.of().mapColor(MapColor.STONE).strength(4.0F, 40.0F).sound(SoundType.STONE)));

    public static final RegistryObject<Block> TRENCH_PLANKS = reg("trench_planks", () ->
            new Block(BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(1.5F, 4.0F).sound(SoundType.WOOD)));

    public static final RegistryObject<Block> BARBED_WIRE = reg("barbed_wire", () ->
            new BarbedWireBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).noCollission().noOcclusion()
                    .strength(1.0F).sound(SoundType.CHAIN)));

    public static final RegistryObject<Block> SPIKE_PIT = reg("spike_pit", () ->
            new SpikePitBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).noOcclusion()
                    .strength(1.5F).sound(SoundType.METAL)));

    public static final RegistryObject<Block> LANDMINE = reg("landmine", () ->
            new LandmineBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).noOcclusion()
                    .strength(1.0F).sound(SoundType.METAL)));

    private static <T extends Block> RegistryObject<T> reg(String name, Supplier<T> supplier) {
        RegistryObject<T> block = BLOCKS.register(name, supplier);
        ModItems.ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
        return block;
    }
}
