package com.shkawy.warmod.world;

import com.shkawy.warmod.registry.ModBlocks;
import com.shkawy.warmod.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Builds the war bases. Coordinates are relative to an origin:
 * f = blocks forward (direction the player faces), r = blocks to the right, y = height.
 */
public final class BaseBuilder {
    private BaseBuilder() {}

    private static BlockPos pos(BlockPos o, Direction d, int f, int r, int y) {
        Direction right = d.getClockWise();
        return o.offset(d.getStepX() * f + right.getStepX() * r, y, d.getStepZ() * f + right.getStepZ() * r);
    }

    private static void set(Level l, BlockPos o, Direction d, int f, int r, int y, BlockState s) {
        l.setBlock(pos(o, d, f, r, y), s, 3);
    }

    private static void setIfAir(Level l, BlockPos o, Direction d, int f, int r, int y, BlockState s) {
        BlockPos p = pos(o, d, f, r, y);
        if (l.getBlockState(p).isAir()) {
            l.setBlock(p, s, 3);
        }
    }

    private static void fill(Level l, BlockPos o, Direction d, int f1, int f2, int r1, int r2, int y1, int y2, BlockState s) {
        for (int f = f1; f <= f2; f++)
            for (int r = r1; r <= r2; r++)
                for (int y = y1; y <= y2; y++)
                    set(l, o, d, f, r, y, s);
    }

    // ------------------------------------------------------------------ WW1 trench
    public static void buildTrench(Level l, BlockPos o, Direction d) {
        BlockState air = Blocks.AIR.defaultBlockState();
        BlockState sand = ModBlocks.SANDBAG.get().defaultBlockState();
        BlockState plank = ModBlocks.TRENCH_PLANKS.get().defaultBlockState();
        BlockState wire = ModBlocks.BARBED_WIRE.get().defaultBlockState();
        BlockState mine = ModBlocks.LANDMINE.get().defaultBlockState();
        BlockState spikes = ModBlocks.SPIKE_PIT.get().defaultBlockState();

        // dig the trench (3 deep) and clear everything above it
        fill(l, o, d, 0, 16, -2, 2, -3, 5, air);
        // duckboard floor and fire step
        fill(l, o, d, 0, 16, -1, 1, -3, -3, plank);
        fill(l, o, d, 1, 15, 1, 1, -2, -2, plank);
        // sandbag walls (parapet rises 2 blocks above ground) and closed end
        fill(l, o, d, 0, 16, -2, -2, -3, 1, sand);
        fill(l, o, d, 0, 16, 2, 2, -3, 1, sand);
        fill(l, o, d, 16, 16, -2, 2, -3, 1, sand);
        // lanterns on the back wall
        for (int f = 2; f <= 14; f += 4) {
            set(l, o, d, f, -2, 2, Blocks.LANTERN.defaultBlockState());
        }
        // no man's land: barbed wire, spike pits and mines in front of the trench
        for (int f = -2; f <= 18; f++) {
            setIfAir(l, o, d, f, 5, 0, wire);
            setIfAir(l, o, d, f, 6, 0, wire);
        }
        for (int f = 1; f <= 15; f += 2) {
            setIfAir(l, o, d, f, 3, 0, spikes);
        }
        for (int f = 3; f <= 15; f += 4) {
            setIfAir(l, o, d, f, 4, 0, mine);
        }
    }

    // ------------------------------------------------------------------ WW2 bunker
    public static void buildBunker(Level l, BlockPos o, Direction d) {
        BlockState air = Blocks.AIR.defaultBlockState();
        BlockState concrete = ModBlocks.BUNKER_CONCRETE.get().defaultBlockState();
        BlockState sand = ModBlocks.SANDBAG.get().defaultBlockState();
        BlockState wire = ModBlocks.BARBED_WIRE.get().defaultBlockState();
        BlockState mine = ModBlocks.LANDMINE.get().defaultBlockState();

        // clear the building site
        fill(l, o, d, -2, 10, -6, 6, 0, 6, air);

        // hollow concrete box 9 x 9 x 5
        for (int f = 0; f <= 8; f++) {
            for (int r = -4; r <= 4; r++) {
                for (int y = 0; y <= 4; y++) {
                    boolean wall = f == 0 || f == 8 || r == -4 || r == 4 || y == 0 || y == 4;
                    set(l, o, d, f, r, y, wall ? concrete : air);
                }
            }
        }
        // sandbag layer on the roof
        fill(l, o, d, 0, 8, -4, 4, 5, 5, sand);

        // entrance (1 wide, 2 high)
        fill(l, o, d, 0, 0, 0, 0, 1, 2, air);
        // machine-gun slits
        for (int r = -3; r <= 3; r += 2) {
            set(l, o, d, 8, r, 3, air);
        }
        set(l, o, d, 3, -4, 3, air);
        set(l, o, d, 5, -4, 3, air);
        set(l, o, d, 3, 4, 3, air);
        set(l, o, d, 5, 4, 3, air);

        // hanging lanterns
        BlockState hangingLantern = Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true);
        set(l, o, d, 2, 0, 3, hangingLantern);
        set(l, o, d, 6, 0, 3, hangingLantern);

        // supply chest
        BlockPos chestPos = pos(o, d, 7, -3, 1);
        l.setBlock(chestPos, Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, d.getOpposite()), 3);
        if (l.getBlockEntity(chestPos) instanceof ChestBlockEntity chest) {
            chest.setItem(0, new ItemStack(ModItems.MEDKIT.get(), 4));
            chest.setItem(1, new ItemStack(ModItems.HANDCUFFS.get(), 2));
            chest.setItem(2, new ItemStack(ModItems.BINOCULARS.get()));
            chest.setItem(3, new ItemStack(ModItems.WW2_HELMET.get()));
            chest.setItem(4, new ItemStack(Items.BREAD, 16));
        }

        // sandbag emplacement in front of the entrance
        for (int r : new int[]{-3, -2, 2, 3}) {
            set(l, o, d, -1, r, 0, sand);
            set(l, o, d, -1, r, 1, sand);
        }

        // barbed wire ring + mines
        for (int f = -3; f <= 11; f++) {
            for (int r = -7; r <= 7; r++) {
                if (f == -3 || f == 11 || r == -7 || r == 7) {
                    setIfAir(l, o, d, f, r, 0, wire);
                }
            }
        }
        for (int f : new int[]{1, 4, 7}) {
            setIfAir(l, o, d, f, -5, 0, mine);
            setIfAir(l, o, d, f, 5, 0, mine);
        }
    }
}
