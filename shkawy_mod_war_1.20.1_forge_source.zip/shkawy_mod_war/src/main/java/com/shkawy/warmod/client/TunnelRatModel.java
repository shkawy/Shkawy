package com.shkawy.warmod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shkawy.warmod.ShkawyModWar;
import com.shkawy.warmod.entity.TunnelRat;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

public class TunnelRatModel extends EntityModel<TunnelRat> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(ShkawyModWar.MODID, "tunnel_rat"), "main");

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart tail;
    private final ModelPart legFR;
    private final ModelPart legFL;
    private final ModelPart legBR;
    private final ModelPart legBL;

    public TunnelRatModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.tail = root.getChild("tail");
        this.legFR = root.getChild("leg_fr");
        this.legFL = root.getChild("leg_fl");
        this.legBR = root.getChild("leg_br");
        this.legBL = root.getChild("leg_bl");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition p = mesh.getRoot();
        p.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-3.0F, -3.0F, -5.0F, 6.0F, 5.0F, 10.0F), PartPose.offset(0.0F, 20.0F, 0.0F));
        p.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 16)
                .addBox(-2.5F, -2.5F, -5.0F, 5.0F, 5.0F, 5.0F), PartPose.offset(0.0F, 19.0F, -5.0F));
        p.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(36, 0)
                .addBox(-0.5F, -0.5F, 0.0F, 1.0F, 1.0F, 8.0F), PartPose.offset(0.0F, 19.0F, 5.0F));
        CubeListBuilder leg = CubeListBuilder.create().texOffs(24, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F);
        p.addOrReplaceChild("leg_fr", leg, PartPose.offset(-2.5F, 22.0F, -3.5F));
        p.addOrReplaceChild("leg_fl", leg, PartPose.offset(2.5F, 22.0F, -3.5F));
        p.addOrReplaceChild("leg_br", leg, PartPose.offset(-2.5F, 22.0F, 3.5F));
        p.addOrReplaceChild("leg_bl", leg, PartPose.offset(2.5F, 22.0F, 3.5F));
        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public void setupAnim(TunnelRat entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * ((float) Math.PI / 180F);
        this.head.xRot = headPitch * ((float) Math.PI / 180F);
        float a = (float) Math.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
        this.legFR.xRot = a;
        this.legBL.xRot = a;
        this.legFL.xRot = -a;
        this.legBR.xRot = -a;
        this.tail.yRot = (float) Math.sin(ageInTicks * 0.2F) * 0.3F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
