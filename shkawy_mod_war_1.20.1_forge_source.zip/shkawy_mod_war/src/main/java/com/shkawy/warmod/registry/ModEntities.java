package com.shkawy.warmod.registry;

import com.shkawy.warmod.ShkawyModWar;
import com.shkawy.warmod.entity.TunnelRat;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ShkawyModWar.MODID);

    public static final RegistryObject<EntityType<TunnelRat>> TUNNEL_RAT = ENTITIES.register("tunnel_rat",
            () -> EntityType.Builder.of(TunnelRat::new, MobCategory.MONSTER)
                    .sized(0.6F, 0.5F)
                    .clientTrackingRange(8)
                    .build(ShkawyModWar.MODID + ":tunnel_rat"));
}
