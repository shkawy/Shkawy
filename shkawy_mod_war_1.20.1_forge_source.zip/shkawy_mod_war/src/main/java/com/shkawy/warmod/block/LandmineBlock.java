package com.shkawy.warmod.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Explodes when stepped on (sneak to walk over it safely). The blast does NOT destroy blocks. */
public class LandmineBlock extends Block {
    private static final VoxelShape SHAPE = Block.box(3, 0, 3, 13, 2, 13);

    public LandmineBlock(Properties properties) {
        super(properties);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (level.isClientSide || !(entity instanceof LivingEntity) || entity.isSteppingCarefully()) {
            return;
        }
        level.removeBlock(pos, false);
        level.explode(null, pos.getX() + 0.5D, pos.getY() + 0.3D, pos.getZ() + 0.5D, 3.0F,
                Level.ExplosionInteraction.NONE);
    }
}
