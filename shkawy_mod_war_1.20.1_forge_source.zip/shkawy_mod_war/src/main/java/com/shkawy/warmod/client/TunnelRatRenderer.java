package com.shkawy.warmod.client;

import com.shkawy.warmod.ShkawyModWar;
import com.shkawy.warmod.entity.TunnelRat;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class TunnelRatRenderer extends MobRenderer<TunnelRat, TunnelRatModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ShkawyModWar.MODID, "textures/entity/tunnel_rat.png");

    public TunnelRatRenderer(EntityRendererProvider.Context context) {
        super(context, new TunnelRatModel(context.bakeLayer(TunnelRatModel.LAYER)), 0.3F);
    }

    @Override
    public ResourceLocation getTextureLocation(TunnelRat entity) {
        return TEXTURE;
    }
}
