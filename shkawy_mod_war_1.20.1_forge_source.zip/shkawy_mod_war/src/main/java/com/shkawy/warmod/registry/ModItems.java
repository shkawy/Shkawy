package com.shkawy.warmod.registry;

import com.shkawy.warmod.ShkawyModWar;
import com.shkawy.warmod.item.*;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, ShkawyModWar.MODID);

    // --- WW1 armor ---
    public static final RegistryObject<Item> WW1_HELMET = ITEMS.register("ww1_helmet",
            () -> new ArmorItem(ModArmorMaterials.WW1, ArmorItem.Type.HELMET, new Item.Properties()));
    public static final RegistryObject<Item> WW1_CHESTPLATE = ITEMS.register("ww1_chestplate",
            () -> new ArmorItem(ModArmorMaterials.WW1, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> WW1_LEGGINGS = ITEMS.register("ww1_leggings",
            () -> new ArmorItem(ModArmorMaterials.WW1, ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final RegistryObject<Item> WW1_BOOTS = ITEMS.register("ww1_boots",
            () -> new ArmorItem(ModArmorMaterials.WW1, ArmorItem.Type.BOOTS, new Item.Properties()));

    // --- WW2 armor ---
    public static final RegistryObject<Item> WW2_HELMET = ITEMS.register("ww2_helmet",
            () -> new ArmorItem(ModArmorMaterials.WW2, ArmorItem.Type.HELMET, new Item.Properties()));
    public static final RegistryObject<Item> WW2_CHESTPLATE = ITEMS.register("ww2_chestplate",
            () -> new ArmorItem(ModArmorMaterials.WW2, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> WW2_LEGGINGS = ITEMS.register("ww2_leggings",
            () -> new ArmorItem(ModArmorMaterials.WW2, ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final RegistryObject<Item> WW2_BOOTS = ITEMS.register("ww2_boots",
            () -> new ArmorItem(ModArmorMaterials.WW2, ArmorItem.Type.BOOTS, new Item.Properties()));

    // --- Tools ---
    public static final RegistryObject<Item> TRENCH_KNIFE = ITEMS.register("trench_knife",
            () -> new SwordItem(Tiers.IRON, 1, -1.2F, new Item.Properties()));
    public static final RegistryObject<Item> HANDCUFFS = ITEMS.register("handcuffs",
            () -> new HandcuffsItem(new Item.Properties().durability(16)));
    public static final RegistryObject<Item> BINOCULARS = ITEMS.register("binoculars",
            () -> new BinocularsItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> MEDKIT = ITEMS.register("medkit",
            () -> new MedkitItem(new Item.Properties().stacksTo(8)));

    // --- Base kits (right-click the ground to build) ---
    public static final RegistryObject<Item> TRENCH_KIT = ITEMS.register("trench_kit",
            () -> new BaseKitItem(new Item.Properties().stacksTo(16), BaseKitItem.Kind.TRENCH));
    public static final RegistryObject<Item> BUNKER_KIT = ITEMS.register("bunker_kit",
            () -> new BaseKitItem(new Item.Properties().stacksTo(16), BaseKitItem.Kind.BUNKER));

    // --- Spawn egg ---
    public static final RegistryObject<Item> TUNNEL_RAT_SPAWN_EGG = ITEMS.register("tunnel_rat_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.TUNNEL_RAT, 0x6B5844, 0x2B2118, new Item.Properties()));
}
