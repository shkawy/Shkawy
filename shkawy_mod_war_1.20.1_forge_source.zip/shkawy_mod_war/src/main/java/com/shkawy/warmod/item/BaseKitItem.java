package com.shkawy.warmod.item;

import com.shkawy.warmod.world.BaseBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Right-click the ground: builds a whole WW1 trench or WW2 bunker in the direction you are facing. */
public class BaseKitItem extends Item {
    public enum Kind { TRENCH, BUNKER }

    private final Kind kind;

    public BaseKitItem(Properties properties, Kind kind) {
        super(properties);
        this.kind = kind;
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        Player player = ctx.getPlayer();
        if (!level.isClientSide && player != null) {
            BlockPos origin = ctx.getClickedPos().relative(ctx.getClickedFace());
            Direction dir = player.getDirection();
            if (kind == Kind.TRENCH) {
                BaseBuilder.buildTrench(level, origin, dir);
            } else {
                BaseBuilder.buildBunker(level, origin, dir);
            }
            if (!player.getAbilities().instabuild) {
                ctx.getItemInHand().shrink(1);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
