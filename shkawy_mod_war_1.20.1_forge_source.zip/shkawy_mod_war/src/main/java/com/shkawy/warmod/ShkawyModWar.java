package com.shkawy.warmod;

import com.shkawy.warmod.registry.*;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(ShkawyModWar.MODID)
public class ShkawyModWar {
    public static final String MODID = "shkawy_mod_war";

    public ShkawyModWar() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModPaintings.PAINTINGS.register(bus);
        ModTabs.TABS.register(bus);
    }
}
