package com.shkawy.warmod.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Slows down and hurts anything that walks through it. */
public class BarbedWireBlock extends Block {
    private static final VoxelShape SHAPE = Block.box(0, 0, 0, 16, 10, 16);

    public BarbedWireBlock(Properties properties) {
        super(properties);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        entity.makeStuckInBlock(state, new Vec3(0.4D, 0.6D, 0.4D));
        if (!level.isClientSide && entity instanceof LivingEntity living) {
            living.hurt(level.damageSources().cactus(), 1.0F);
        }
    }
}
