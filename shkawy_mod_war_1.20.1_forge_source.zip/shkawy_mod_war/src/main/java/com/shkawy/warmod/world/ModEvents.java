package com.shkawy.warmod.world;

import com.shkawy.warmod.ShkawyModWar;
import com.shkawy.warmod.entity.TunnelRat;
import com.shkawy.warmod.registry.ModEntities;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ShkawyModWar.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.TUNNEL_RAT.get(), TunnelRat.createAttributes().build());
    }

    @SubscribeEvent
    public static void onSpawnPlacements(SpawnPlacementRegisterEvent event) {
        // Rats only spawn underground (below y=60) in the dark.
        event.register(ModEntities.TUNNEL_RAT.get(),
                SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (type, level, reason, pos, random) ->
                        pos.getY() < 60 && Monster.checkMonsterSpawnRules(type, level, reason, pos, random),
                SpawnPlacementRegisterEvent.Operation.OR);
    }
}
