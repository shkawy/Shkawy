package com.shkawy.warmod.registry;

import com.shkawy.warmod.ShkawyModWar;
import net.minecraft.world.entity.decoration.PaintingVariant;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModPaintings {
    public static final DeferredRegister<PaintingVariant> PAINTINGS =
            DeferredRegister.create(ForgeRegistries.PAINTING_VARIANTS, ShkawyModWar.MODID);

    // sizes are in pixels (16 per block)
    static {
        PAINTINGS.register("ww1_poster", () -> new PaintingVariant(64, 48));
        PAINTINGS.register("ww2_poster", () -> new PaintingVariant(64, 48));
        PAINTINGS.register("trench_dawn", () -> new PaintingVariant(64, 32));
        PAINTINGS.register("bomber_sky", () -> new PaintingVariant(64, 32));
    }
}
