package com.shkawy.warmod.registry;

import com.shkawy.warmod.ShkawyModWar;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.function.Supplier;

public enum ModArmorMaterials implements ArmorMaterial {
    // order of arrays: helmet, chestplate, leggings, boots (same as ArmorItem.Type ordinal)
    WW1("ww1", 16, new int[]{2, 5, 4, 2}, 12, 0.0F, 0.0F, () -> Ingredient.of(Items.IRON_INGOT)),
    WW2("ww2", 30, new int[]{3, 7, 5, 3}, 14, 1.0F, 0.05F, () -> Ingredient.of(Items.IRON_INGOT));

    private static final int[] BASE_DURABILITY = {11, 16, 15, 13};

    private final String name;
    private final int durabilityMultiplier;
    private final int[] defense;
    private final int enchantability;
    private final float toughness;
    private final float knockbackResistance;
    private final Supplier<Ingredient> repair;

    ModArmorMaterials(String name, int durabilityMultiplier, int[] defense, int enchantability,
                      float toughness, float knockbackResistance, Supplier<Ingredient> repair) {
        this.name = ShkawyModWar.MODID + ":" + name;
        this.durabilityMultiplier = durabilityMultiplier;
        this.defense = defense;
        this.enchantability = enchantability;
        this.toughness = toughness;
        this.knockbackResistance = knockbackResistance;
        this.repair = repair;
    }

    @Override public int getDurabilityForType(ArmorItem.Type type) { return BASE_DURABILITY[type.ordinal()] * durabilityMultiplier; }
    @Override public int getDefenseForType(ArmorItem.Type type) { return defense[type.ordinal()]; }
    @Override public int getEnchantmentValue() { return enchantability; }
    @Override public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_IRON; }
    @Override public Ingredient getRepairIngredient() { return repair.get(); }
    @Override public String getName() { return name; }
    @Override public float getToughness() { return toughness; }
    @Override public float getKnockbackResistance() { return knockbackResistance; }
}
