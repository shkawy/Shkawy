SHKAWY MOD WAR  -  Minecraft 1.20.1  -  Forge 47.3.0
=====================================================

HOW TO BUILD THE .JAR (needs JDK 17 + internet)
------------------------------------------------
Option A (easiest):
  1. Download the Forge MDK for 1.20.1 (47.3.0) from files.minecraftforge.net
  2. Extract it, DELETE its "src" folder, and copy THIS project's "src" folder,
     "build.gradle", "settings.gradle" and "gradle.properties" over it.
  3. Open a terminal in that folder and run:
        Windows:  gradlew build
        Linux/Mac: ./gradlew build
  4. Your mod is in:  build/libs/shkawy_mod_war-1.20.1-1.0.0.jar
  5. Put the jar in .minecraft/mods and launch Forge 1.20.1.

Option B: install Gradle 8.1.1, run "gradle wrapper" in this folder, then "gradlew build".

WHAT IS INSIDE
--------------
Blocks : Sandbag, Bunker Concrete, Trench Duckboards, Barbed Wire (slows + hurts),
         Spike Pit (hurts), Landmine (explodes, sneak to cross safely, no block damage)
Items  : WW1 armor set, WW2 armor set, Trench Knife, Handcuffs (right-click mob/player),
         Binoculars (highlights everything near you), Medkit
Kits   : WW1 Trench Kit + WW2 Bunker Kit - right-click the ground and a full base is built
         (trench with duckboards, walls, lanterns, barbed wire, spikes, mines /
          concrete bunker with slits, supply chest, wire ring, mines)
Mob    : Tunnel Rat - poisonous rat that spawns underground in the dark
Extras : 4 war paintings (place with the vanilla Painting item), crafting recipes for
         everything, creative tab "Shkawy Mod War", English + Arabic language files.
Resources total about 7 MB, so the jar is well over 3 MB.
